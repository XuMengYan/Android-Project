package com.example.minidouyin.classes;

import android.app.Activity;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.minidouyin.MainActivity;
import com.example.minidouyin.R;
import com.example.minidouyin.network_models.Video;

import java.util.List;

public class VideoAdapter extends  RecyclerView.Adapter<VideoViewHolder> {

    private List<Video> mVideos;
    private Activity currentActivity;

    public VideoAdapter(Activity act, List<Video> vList)
    {
        mVideos = vList;
        currentActivity = act;
    }

    @NonNull
    @Override
    public VideoViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                        .inflate(R.layout.video_layout, viewGroup, false);
        VideoViewHolder holder = new VideoViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull VideoViewHolder holder, int pos) {
        final Video video = mVideos.get(pos);
        holder.bind(currentActivity, video);
    }

    @Override
    public int getItemCount() {
        return mVideos.size();
    }
}
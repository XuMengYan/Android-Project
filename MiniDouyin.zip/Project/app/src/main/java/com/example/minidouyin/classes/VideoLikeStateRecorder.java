package com.example.minidouyin.classes;

import java.util.HashMap;
import java.util.Map;

public class VideoLikeStateRecorder {

    static Map<String, Integer> map = new HashMap<>();

    public static void setState(String url, int state)
    {
        map.put(url, state);
    }

    public static int getState(String url)
    {
        if(!map.containsKey(url))
        {
            map.put(url, 0);
        }
        return map.get(url);
    }

}

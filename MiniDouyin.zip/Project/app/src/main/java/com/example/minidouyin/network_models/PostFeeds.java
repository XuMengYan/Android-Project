package com.example.minidouyin.network_models;

import com.google.gson.annotations.SerializedName;

public class PostFeeds {

    @SerializedName("success")
    public boolean successful;

}

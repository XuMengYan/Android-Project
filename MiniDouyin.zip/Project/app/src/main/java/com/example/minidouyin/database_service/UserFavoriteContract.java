package com.example.minidouyin.database_service;

import android.provider.BaseColumns;

public class UserFavoriteContract {

    public static final String TABLE_NAME = "user_favorite";
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_USER_NAME = "user_name";
    public static final String COLUMN_URL = "url";

    public static final String SQL_CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + "(" + COLUMN_USER_ID + " TEXT, " + COLUMN_USER_NAME + " TEXT, " + COLUMN_URL + " TEXT)";

    private UserFavoriteContract(){}
}


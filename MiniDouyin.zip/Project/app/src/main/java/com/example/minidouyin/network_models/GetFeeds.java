package com.example.minidouyin.network_models;

import com.google.gson.annotations.SerializedName;

import java.util.List;


public class GetFeeds {

    @SerializedName("feeds")
    public List<Video> videos;

    @SerializedName("success")
    public boolean successful;

}

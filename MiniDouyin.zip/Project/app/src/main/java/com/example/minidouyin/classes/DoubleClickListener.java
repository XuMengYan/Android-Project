package com.example.minidouyin.classes;

import android.os.AsyncTask;
import android.view.View;

import androidx.annotation.UiThread;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public abstract class DoubleClickListener implements View.OnClickListener {

    private static final long DOUBLE_CLICK_MAX_INTERVAL = 1000;
    private static long lastClickTime = 0;
    private static long clickTime = 0;
    private static int clickType = 0;
    private static ScheduledExecutorService doubleClickCheck = Executors.newSingleThreadScheduledExecutor();

    @Override
    public void onClick(final View view) {
        lastClickTime = System.currentTimeMillis();
        clickTime++;

        if(clickTime == 1)
        doubleClickCheck.schedule(new Runnable() {
            @Override
            public void run() {
                if(clickTime <= 1) clickType = 1; else clickType = 2;
                if(clickType == 1)
                {
                    view.post(new Runnable() {
                        @Override
                        public void run() {
                            onSingleClick(view);
                        }
                    });
                }
                else if(clickType == 2)
                {
                    view.post(new Runnable() {
                        @Override
                        public void run() {
                            onDoubleClick(view);
                        }
                    });
                }
                clickTime = 0;
                clickType = 0;
            }
        }, DOUBLE_CLICK_MAX_INTERVAL, TimeUnit.MILLISECONDS);
    }

    public abstract void onSingleClick(View view);
    public abstract void onDoubleClick(View view);
}

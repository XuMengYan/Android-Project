package com.example.minidouyin.database_service;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DBOperations {

    private static String userName = new String();
    private static String userID = new String();
    private static SQLiteDatabase db;

    public static List<String> favouriteURL = new ArrayList<>();
    public static boolean favoriteChanged = false;

    public static void setDatabase(SQLiteDatabase database)
    {
        db = database;
        favoriteChanged = true;
    }

    public static boolean dbServiceOn()
    {
        return db != null;
    }


    public static void setUser(String name, String id)
    {
        userName = name;
        userID = id;
        favoriteChanged = true;
    }

    public static String getUserName()
    {
        return userName;
    }
    public static String getUserID()
    {
        return userID;
    }

    public static boolean loggedIn()
    {
        return userName.length() > 0 && userID.length() > 0;
    }

    public static void logOff()
    {
        userName = new String();
        userID = new String();
        favouriteURL.clear();
        favoriteChanged = true;
    }

    public static List<String> getFavoriteUrl()
    {
        if(!loggedIn()) return new ArrayList<>();

        if(!favoriteChanged)
            return favouriteURL;
        else
        {
            favouriteURL = getFavoriteUrlFromDB();
            favoriteChanged = false;
            return favouriteURL;
        }
    }


    public static List<String> getFavoriteUrlFromDB()
    {
        if(db == null) return Collections.emptyList();
        List<String> ret = new ArrayList<>();
        Cursor cursor = null;
        try
        {
            cursor = db.query(UserFavoriteContract.TABLE_NAME, new String[]{UserFavoriteContract.COLUMN_URL},
                    UserFavoriteContract.COLUMN_USER_NAME + "=? and " + UserFavoriteContract.COLUMN_USER_ID + "=?",
                    new String[]{userName, userID},
                    null, null, null);

            while(cursor.moveToNext())
            {
                ret.add(cursor.getString(cursor.getColumnIndex(UserFavoriteContract.COLUMN_URL)));
            }
        } finally {
            if(cursor != null) cursor.close();
        }
        return ret;
    }

    public static int addFavorite(String url)
    {
        favoriteChanged = true;
        if(db == null) return -1;
        long ret = 0;
        try
        {
            ContentValues values = new ContentValues();
            values.put(UserFavoriteContract.COLUMN_USER_NAME, userName);
            values.put(UserFavoriteContract.COLUMN_USER_ID, userID);
            values.put(UserFavoriteContract.COLUMN_URL, url);
            ret = db.insert(UserFavoriteContract.TABLE_NAME, null, values);
        }
        catch (Exception x)
        {
            return -1;
        }
        return (int)ret;
    }

    public static int deleteFavorite(String url)
    {
        favoriteChanged = true;
        if(db == null) return -1;
        long ret = 0;
        try
        {
            ret = db.delete(UserFavoriteContract.TABLE_NAME,
                    UserFavoriteContract.COLUMN_USER_NAME + "=? and " +
                                UserFavoriteContract.COLUMN_USER_ID + " =? and " +
                                UserFavoriteContract.COLUMN_URL + " =? ",
                    new String[]{userName, userID, url});
        }
        catch (Exception x)
        {
            return -1;
        }
        return (int)ret;
    }

}

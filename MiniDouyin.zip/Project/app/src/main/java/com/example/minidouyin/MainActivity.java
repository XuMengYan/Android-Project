package com.example.minidouyin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Toast;

import com.example.minidouyin.database_service.DBOperations;
import com.example.minidouyin.database_service.UserFavoriteDBHelper;
import com.example.minidouyin.fragments.FragmentGetVideo;
import com.example.minidouyin.fragments.FragmentMine;
import com.example.minidouyin.fragments.FragmentPostVideo;
import com.google.android.material.tabs.TabLayout;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class MainActivity extends AppCompatActivity {

    public static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 2100;
    public static final int MY_PERMISSIONS_REQUEST_CAMERA = 2101;
    public static final int MY_PERMISSIONS_REQUEST_RECORD_AUDIO = 2102;
    static boolean firstOpen = true;

    private SQLiteDatabase database;
    private UserFavoriteDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        dbHelper = new UserFavoriteDBHelper(this);

        database = dbHelper.getWritableDatabase();
        DBOperations.setDatabase(database);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FileReader reader = null;
        if(firstOpen)
        {
            firstOpen = false;
            try
            {
                File file = new File(getFilesDir() + "/login.txt");
                if(file.exists())
                {
                    reader = new FileReader(file);
                    String content = new String();
                    int x = 0;
                    while(x != -1)
                    {
                        x = reader.read();
                        if(x != -1) content += (char)x;
                    }
                    reader.close();
                    if(content.length() > 0)
                    {
                        String info[] = content.split("\n");
                        if(info[0] != null && info[1] != null)
                        {
                            DBOperations.setUser(info[0], info[1]);
                        }
                    }
                }
            }
            catch (Exception x)
            { }
            finally {
                try
                {
                    if(reader != null) reader.close();
                }
                catch (Exception x){
                    Toast.makeText(MainActivity.this, "File IO Failed", Toast.LENGTH_SHORT).show();
                }
            }
        }

        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED)
        {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);
        }

        TabLayout tab = findViewById(R.id.tabLayout_menu);
        tab.addTab(tab.newTab().setText("Videos"));
        tab.addTab(tab.newTab().setText("Post Video"));
        tab.addTab(tab.newTab().setText("Mine"));

        final FragmentManager fmanager = getSupportFragmentManager();

        FragmentTransaction ftransac = fmanager.beginTransaction();
        ftransac.replace(R.id.fragment_container, new FragmentGetVideo());
        ftransac.commit();

        tab.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if(tab.getPosition() == 0)
                {
                    FragmentTransaction ftransac = fmanager.beginTransaction();
                    ftransac.replace(R.id.fragment_container, new FragmentGetVideo());
                    ftransac.commit();
                }
                if(tab.getPosition() == 1)
                {
                    FragmentTransaction ftransac = fmanager.beginTransaction();
                    ftransac.replace(R.id.fragment_container, new FragmentPostVideo());
                    ftransac.commit();
                }
                if(tab.getPosition() == 2)
                {
                    FragmentTransaction ftransac = fmanager.beginTransaction();
                    FragmentMine fragM = new FragmentMine();
                    ftransac.replace(R.id.fragment_container, fragM);
                    ftransac.commit();
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        database.close();
        database = null;
        dbHelper.close();
        dbHelper = null;
    }

}

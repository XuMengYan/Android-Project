package com.example.minidouyin.classes;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.minidouyin.R;
import com.example.minidouyin.VideoActivity;
import com.example.minidouyin.database_service.DBOperations;
import com.example.minidouyin.network_models.Video;

import java.util.List;

public class VideoViewHolder extends RecyclerView.ViewHolder {

    //public Context toastContext;
    public ImageView cover, like, favorite, comment;
    public View videoView;
    public LinearLayout commentSpace;
    public Button commentSendBtn;
    public TextView uploadUser, uploadTime;
    private int likeT = 0, favT = 0;

    public VideoViewHolder(@NonNull View itemView)
    {
        super(itemView);
        videoView = itemView;
        cover = videoView.findViewById(R.id.cover_image);
        like = videoView.findViewById(R.id.like_img);
        favorite = videoView.findViewById(R.id.favorite_img);
        comment = videoView.findViewById(R.id.comment_img);
        commentSpace = videoView.findViewById(R.id.comment_place);
        commentSendBtn = videoView.findViewById(R.id.comment_send_btn);
        uploadUser = videoView.findViewById(R.id.tv_upload_user);
        uploadTime = videoView.findViewById(R.id.tv_upload_time);
    }

    public void bind(final Activity activity, final Video video)
    {
        uploadUser.setText(video.getUserName());
        uploadTime.setText(video.getVideoCreateTime().split("T")[0]);

        Glide.with(cover.getContext()).load(video.getImageUrl()).into(cover);
        cover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                VideoActivity.launch(activity, video.getVideoUrl());
            }
        });
        if(VideoLikeStateRecorder.getState(video.getVideoUrl()) == 0)
            like.setImageResource(R.drawable.like);
        else
            like.setImageResource(R.drawable.like_red);
        if(DBOperations.loggedIn())
        {
            List<String> list = DBOperations.getFavoriteUrl();
            if(list.contains(video.getVideoUrl()))
                favorite.setImageResource(R.drawable.favorite_red);
            else
                favorite.setImageResource(R.drawable.favorite);
        }
        else
            favorite.setImageResource(R.drawable.favorite);
        like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int x = VideoLikeStateRecorder.getState(video.getVideoUrl());
                x = 1 - x;
                VideoLikeStateRecorder.setState(video.getVideoUrl(), x);
                if(x == 0)
                    like.setImageResource(R.drawable.like);
                else
                {
                    like.setImageResource(R.drawable.like_red);
                    Animator anim = AnimatorInflater.loadAnimator(like.getContext(), R.animator.click_on_like_fav);
                    anim.setTarget(like);
                    anim.start();
                }
            }
        });
        favorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //TODO: Update favorite info with this click
                if(!DBOperations.loggedIn())
                {
                    Toast.makeText(videoView.getContext(), "Please log in first", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(DBOperations.getFavoriteUrl().contains(video.getVideoUrl()))
                {
                    favorite.setImageResource(R.drawable.favorite);
                    DBOperations.deleteFavorite(video.getVideoUrl());
                }
                else
                {
                    favorite.setImageResource(R.drawable.favorite_red);
                    DBOperations.addFavorite(video.getVideoUrl());
                    Animator anim = AnimatorInflater.loadAnimator(favorite.getContext(), R.animator.click_on_like_fav);
                    anim.setTarget(favorite);
                    anim.start();
                }
            }
        });
        comment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!DBOperations.loggedIn())
                {
                    Toast.makeText(videoView.getContext(), "Please log in first", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(commentSpace.getVisibility() == View.GONE)
                    commentSpace.setVisibility(View.VISIBLE);
                else
                    commentSpace.setVisibility(View.GONE);

            }
        });
        commentSendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(activity,  "Comment sent", Toast.LENGTH_LONG).show();
                commentSpace.setVisibility(View.GONE);
            }
        });

    }
}

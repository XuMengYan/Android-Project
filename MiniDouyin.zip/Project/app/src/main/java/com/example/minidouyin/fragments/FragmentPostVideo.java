package com.example.minidouyin.fragments;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.example.minidouyin.ChooseCoverFromVideoActivity;
import com.example.minidouyin.CustomVideoShotActivity;
import com.example.minidouyin.MainActivity;
import com.example.minidouyin.R;
import com.example.minidouyin.database_service.DBOperations;
import com.example.minidouyin.network_models.PostFeeds;
import com.example.minidouyin.network_service.IMiniDouyinService;
import com.example.minidouyin.resource_service.FileService;
import com.example.minidouyin.resource_service.ResourceUtils;

import java.io.File;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.app.Activity.RESULT_OK;
import static android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE;
import static android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;

public class FragmentPostVideo extends Fragment {

    final static int PICK_IMAGE = 50;
    final static int PICK_VIDEO = 51;
    final static int CAPTURE_IMAGE = 52;
    final static int CAPTURE_VIDEO = 53;
    final static int CAPTURE_VIDEO_CUSTOM = 54;
    final static int PICK_IMAGE_FROM_VIDEO = 55;
    final static int CAPTURE_VIDEO_CUSTOM_UNLIMITED = 56;

    private Uri mSelectedImageUri = null;
    private Uri mSelectedVideoUri = null;
    private File mImageFile = null;
    private File mVideoFile = null;

    private View fragmentView;
    private Button btnImageAlbum;
    private Button btnVideoAlbum;
    private Button btnPost;
    private Button btnImageCamera;
    private Button btnVideoCamera;
    private Button btnVideoCustom;
    private Button btnVideoCustomUnlim;
    private TextView tvSelectImage;
    private TextView tvSelectVideo;
    private CheckBox cbGetCoverFromVideo;

    private ImageView imageViewPreview;
    private VideoView videoViewPreview;


    private Retrofit retrofit;
    private IMiniDouyinService miniDouyinService;
    private static final OkHttpClient client = new OkHttpClient.Builder().
            connectTimeout(60, TimeUnit.SECONDS).
            readTimeout(60, TimeUnit.SECONDS).
            writeTimeout(60, TimeUnit.SECONDS).build();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_post_video, container, false);

        if(!DBOperations.loggedIn())
        {
            LinearLayout in, out;
            in = view.findViewById(R.id.fragment_post_main_layout);
            in.setVisibility(View.GONE);
            out = view.findViewById(R.id.fragment_post_not_login);
            out.setVisibility(View.VISIBLE);
            return view;
        }
        else
        {
            LinearLayout in, out;
            in = view.findViewById(R.id.fragment_post_main_layout);
            in.setVisibility(View.VISIBLE);
            out = view.findViewById(R.id.fragment_post_not_login);
            out.setVisibility(View.GONE);
        }

        retrofit = new Retrofit.Builder().baseUrl("http://test.androidcamp.bytedance.com/mini_douyin/invoke/")
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        miniDouyinService = retrofit.create(IMiniDouyinService.class);
        fragmentView = view;
        imageViewPreview = fragmentView.findViewById(R.id.image_preview);
        videoViewPreview = fragmentView.findViewById(R.id.video_preview);
        btnImageAlbum = fragmentView.findViewById(R.id.btn_select_image_from_album);
        btnVideoAlbum = fragmentView.findViewById(R.id.btn_select_video_from_album);
        btnPost = fragmentView.findViewById(R.id.btn_post_video);
        btnImageCamera = fragmentView.findViewById(R.id.btn_select_image_from_camera);
        btnVideoCamera = fragmentView.findViewById(R.id.btn_select_video_from_camera);
        btnVideoCustom = fragmentView.findViewById(R.id.btn_select_video_custom_shot);
        btnVideoCustomUnlim = fragmentView.findViewById(R.id.btn_select_video_custom_unlimited);
        tvSelectImage = fragmentView.findViewById(R.id.tv_select_cover);
        tvSelectVideo = fragmentView.findViewById(R.id.tv_select_video);
        cbGetCoverFromVideo = fragmentView.findViewById(R.id.cb_generate_from_video);

        String str;
        str = Integer.toString(CustomVideoShotActivity.CUSTOM_RECORD_TIME) + btnVideoCustom.getText().toString();
        btnVideoCustom.setText(str);

        cbGetCoverFromVideo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                {
                    tvSelectImage.setText("Select a cover image √");
                    imageViewPreview.setImageDrawable(null);
                    mSelectedImageUri = null;
                    btnImageAlbum.setEnabled(false);
                    btnImageCamera.setEnabled(false);
                    if(mSelectedVideoUri != null)
                    {
                        Intent chooseCover = new Intent(FragmentPostVideo.this.getContext(), ChooseCoverFromVideoActivity.class);
                        chooseCover.setData(mSelectedVideoUri);
                        startActivityForResult(chooseCover, PICK_IMAGE_FROM_VIDEO);
                    }
                }
                else
                {
                    tvSelectImage.setText("Select a cover image");
                    btnImageAlbum.setEnabled(true);
                    btnImageCamera.setEnabled(true);
                }
            }
        });

        btnImageAlbum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, PICK_IMAGE);
            }
        });

        btnVideoAlbum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("video/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Video"), PICK_VIDEO);
            }
        });

        btnImageCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean flag = true;
                if (getActivity().checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MainActivity.MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);
                    flag = false;
                }
                if (getActivity().checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[]{Manifest.permission.CAMERA},
                            MainActivity.MY_PERMISSIONS_REQUEST_CAMERA);
                    flag = false;
                }
                if(flag)
                {
                    Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    mImageFile = FileService.getOutputMediaFile(MEDIA_TYPE_IMAGE);
                    if(mImageFile != null)
                    {
                        //try{mImageFile.createNewFile();}catch (Exception x){}
                        Uri fileUri = FileProvider.getUriForFile(FragmentPostVideo.this.getContext(), "com.example.minidouyin", mImageFile);
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
                        takePictureIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        startActivityForResult(takePictureIntent, CAPTURE_IMAGE);
                    }
                }
            }
        });

        btnVideoCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean flag = true;
                if (getActivity().checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            MainActivity.MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);
                    flag = false;
                }
                if (getActivity().checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[]{Manifest.permission.CAMERA},
                            MainActivity.MY_PERMISSIONS_REQUEST_CAMERA);
                    flag = false;
                }
                if (getActivity().checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},
                            MainActivity.MY_PERMISSIONS_REQUEST_RECORD_AUDIO);
                    flag = false;
                }
                if(flag)
                {
                    Intent videoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                    mVideoFile = FileService.getOutputMediaFile(MEDIA_TYPE_VIDEO);
                    if(mVideoFile != null)
                    {
                        //try{mImageFile.createNewFile();}catch (Exception x){}
                        Uri fileUri = FileProvider.getUriForFile(FragmentPostVideo.this.getContext(), "com.example.minidouyin", mVideoFile);
                        videoIntent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
                        videoIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        startActivityForResult(videoIntent, CAPTURE_VIDEO);
                    }
                }
            }
        });

        btnVideoCustom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean flag = true;
                if (getActivity().checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            MainActivity.MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);
                    flag = false;
                }
                if (getActivity().checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[]{Manifest.permission.CAMERA},
                            MainActivity.MY_PERMISSIONS_REQUEST_CAMERA);
                    flag = false;
                }
                if (getActivity().checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},
                            MainActivity.MY_PERMISSIONS_REQUEST_RECORD_AUDIO);
                    flag = false;
                }
                if(!flag) return;
                Intent intent = new Intent(FragmentPostVideo.this.getContext(), CustomVideoShotActivity.class);
                startActivityForResult(intent, CAPTURE_VIDEO_CUSTOM);
            }
        });

        btnVideoCustomUnlim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean flag = true;
                if (getActivity().checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            MainActivity.MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);
                    flag = false;
                }
                if (getActivity().checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[]{Manifest.permission.CAMERA},
                            MainActivity.MY_PERMISSIONS_REQUEST_CAMERA);
                    flag = false;
                }
                if (getActivity().checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},
                            MainActivity.MY_PERMISSIONS_REQUEST_RECORD_AUDIO);
                    flag = false;
                }
                if(!flag) return;
                Intent intent = new Intent(FragmentPostVideo.this.getContext(), CustomVideoShotActivity.class);
                intent.putExtra("unlim", 1);
                startActivityForResult(intent, CAPTURE_VIDEO_CUSTOM_UNLIMITED);
            }
        });

        btnPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postVideo();
            }
        });


        return fragmentView;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Context context = FragmentPostVideo.this.getContext();

        switch (requestCode)
        {
            case PICK_IMAGE:
                if(data != null)
                {
                    mSelectedImageUri = data.getData();
                    Glide.with(context).load(mSelectedImageUri).into(imageViewPreview);
                }
                break;
            case PICK_VIDEO:
                if(data != null)
                {
                    mSelectedVideoUri = data.getData();
                    videoViewPreview.setVideoURI(mSelectedVideoUri);
                    videoViewPreview.setVisibility(View.VISIBLE);
                    videoViewPreview.start();
                }
                break;
            case CAPTURE_IMAGE:
                if(resultCode == RESULT_OK)
                {
                    int tgtW = imageViewPreview.getWidth();
                    int tgtH = imageViewPreview.getHeight();
                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inJustDecodeBounds = true;
                    BitmapFactory.decodeFile(mImageFile.getAbsolutePath(), options);
                    int photoW = options.outWidth;
                    int photoH = options.outHeight;
                    int scaleFactor = Math.min(photoH/tgtH, photoW/tgtW);
                    options.inJustDecodeBounds = false;
                    options.inSampleSize = scaleFactor;
                    options.inPurgeable = true;
                    Bitmap bmp =  BitmapFactory.decodeFile(mImageFile.getAbsolutePath(), options);
                    Bitmap rbmp = FileService.rotateImage(bmp, mImageFile.getAbsolutePath());

                    Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                    Uri uri = Uri.fromFile(mImageFile);
                    intent.setData(uri);
                    FragmentPostVideo.this.getActivity().sendBroadcast(intent);
                    imageViewPreview.setImageBitmap(rbmp);
                    mSelectedImageUri = uri;
                }
                break;
            case CAPTURE_VIDEO:
                if(resultCode == RESULT_OK)
                {
                    Uri uri = Uri.fromFile(mVideoFile);
                    mSelectedVideoUri = uri;
                    videoViewPreview.setVideoURI(uri);
                    videoViewPreview.setVisibility(View.VISIBLE);
                    videoViewPreview.start();
                    Intent broadcast = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                    broadcast.setData(uri);
                    FragmentPostVideo.this.getActivity().sendBroadcast(broadcast);
                }
                break;
            case CAPTURE_VIDEO_CUSTOM:
                if(resultCode == 233)
                {
                    Uri uri = data.getData();
                    mSelectedVideoUri = uri;
                    videoViewPreview.setVideoURI(uri);
                    videoViewPreview.setVisibility(View.VISIBLE);
                    videoViewPreview.start();
                    Intent broadcast = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                    broadcast.setData(uri);
                    FragmentPostVideo.this.getActivity().sendBroadcast(broadcast);
                }
                break;
            case PICK_IMAGE_FROM_VIDEO:
                if(resultCode == 233)
                {
                    Uri uri = data.getData();
                    mSelectedImageUri = uri;
                    imageViewPreview.setImageURI(uri);
                    Intent broadcast = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                    broadcast.setData(uri);
                    FragmentPostVideo.this.getActivity().sendBroadcast(broadcast);
                    if(data.getBooleanExtra("immediate_post", false))
                    {
                        btnPost.setEnabled(false);
                        btnPost.callOnClick();
                    }
                    videoViewPreview.setVideoURI(mSelectedVideoUri);
                    videoViewPreview.setVisibility(View.VISIBLE);
                    videoViewPreview.start();
                }
                break;
            case CAPTURE_VIDEO_CUSTOM_UNLIMITED:
                if(resultCode == 233)
                {
                    Uri uri = data.getData();
                    mSelectedVideoUri = uri;
                    videoViewPreview.setVideoURI(uri);
                    videoViewPreview.setVisibility(View.VISIBLE);
                    videoViewPreview.start();
                    Intent broadcast = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                    broadcast.setData(uri);
                    FragmentPostVideo.this.getActivity().sendBroadcast(broadcast);
                }
                break;
        }

        if(requestCode == PICK_VIDEO  && resultCode == RESULT_OK
                || requestCode == CAPTURE_VIDEO && resultCode == RESULT_OK
                || requestCode == CAPTURE_VIDEO_CUSTOM && resultCode == 233
                || requestCode == CAPTURE_VIDEO_CUSTOM_UNLIMITED && resultCode == 233)
        {
            if(cbGetCoverFromVideo.isChecked())
            {
                Intent chooseCover = new Intent(FragmentPostVideo.this.getContext(), ChooseCoverFromVideoActivity.class);
                chooseCover.setData(mSelectedVideoUri);
                startActivityForResult(chooseCover, PICK_IMAGE_FROM_VIDEO);
            }
        }

        if(mSelectedImageUri != null)
            tvSelectImage.setText("Select a cover image √");
        else
            tvSelectImage.setText("Select a cover image");
        if(mSelectedVideoUri != null)
            tvSelectVideo.setText("Select a video √");
        else
            tvSelectVideo.setText("Select a video");
        if(mSelectedVideoUri != null && mSelectedImageUri != null)
        {
            btnPost.setEnabled(true);
        }
    }

    private MultipartBody.Part getMultipartFromUri(String name, Uri uri) {
        File f = new File(ResourceUtils.getRealPath(FragmentPostVideo.this.getContext(), uri));
        RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), f);
        return MultipartBody.Part.createFormData(name, f.getName(), requestFile);
    }

    private void postVideo()
    {
        btnPost.setText("POSTING...");
        btnPost.setEnabled(false);
        MultipartBody.Part coverImagePart = getMultipartFromUri("cover_image", mSelectedImageUri);
        MultipartBody.Part videoPart = getMultipartFromUri("video", mSelectedVideoUri);
        Call<PostFeeds> call = miniDouyinService.uploadVideo(DBOperations.getUserID(), DBOperations.getUserName(), coverImagePart, videoPart);
        call.enqueue(new Callback<PostFeeds>() {
            @Override
            public void onResponse(Call<PostFeeds> call, Response<PostFeeds> response) {
                if(response != null && response.isSuccessful())
                {
                    Toast t = Toast.makeText(FragmentPostVideo.this.getContext(), "Upload Successful", Toast.LENGTH_SHORT);
                    t.show();
                }
                else
                {
                    Toast t = Toast.makeText(FragmentPostVideo.this.getContext(), "Upload Failed", Toast.LENGTH_LONG);
                    t.show();
                }
                btnPost.setEnabled(true);
                btnPost.setText("POST");
            }

            @Override
            public void onFailure(Call<PostFeeds> call, Throwable throwable) {
                Toast t = Toast.makeText(FragmentPostVideo.this.getContext(), "Upload Failed, please check your network", Toast.LENGTH_LONG);
                t.show();
                btnPost.setEnabled(true);
                btnPost.setText("POST");
            }
        });
    }





}

package com.example.minidouyin;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.hardware.Camera;
import android.media.CamcorderProfile;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.example.minidouyin.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ScheduledExecutorService;

import static android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE;
import static android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;
import static com.example.minidouyin.resource_service.FileService.getOutputMediaFile;


public class CustomVideoShotActivity extends AppCompatActivity {

    public static final int CUSTOM_RECORD_TIME = 5;

    private SurfaceView mSurfaceView;
    private Camera mCamera;

    private int CAMERA_TYPE = Camera.CameraInfo.CAMERA_FACING_BACK;

    private boolean isRecording = false;

    private int rotationDegree = 0;
    private int timeCount = 0;
    private Timer mTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_custom_video_shot);

        releaseCameraAndPreview();
        mCamera = getCamera(CAMERA_TYPE);
        mTimer = new Timer();

        mSurfaceView = findViewById(R.id.img);
        final SurfaceHolder holder = mSurfaceView.getHolder();
        holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        holder.addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                try
                {
                    mCamera.setPreviewDisplay(holder);
                    mCamera.startPreview();
                } catch (Exception x){}
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                releaseCameraAndPreview();
            }
        });

        final int unlimited = getIntent().getIntExtra("unlim", 0);

        final ScheduledExecutorService tenSecondMonitor = null;
        final Button btnRecord = findViewById(R.id.btn_record);
        final Button btnFacing = findViewById(R.id.btn_facing);
        final Button btnFlash = findViewById(R.id.btn_flashlight);
        btnRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(unlimited == 0)
                {
                    btnRecord.setEnabled(false);
                    btnFacing.setEnabled(false);
                    btnFlash.setEnabled(false);
                    isRecording = true;
                    timeCount = CUSTOM_RECORD_TIME;
                    btnRecord.setText(Integer.toString(CUSTOM_RECORD_TIME));
                    prepareVideoRecorder();
                    try{
                        mMediaRecorder.prepare();
                        mMediaRecorder.start();
                    }
                    catch (Exception x){
                        releaseMediaRecorder();
                    }
                    mTimer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            --timeCount;
                            if(timeCount != 0)
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        btnRecord.setText(Integer.toString(timeCount));
                                    }
                                });
                            else
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        btnRecord.setText("record");
                                        releaseMediaRecorder();
                                        isRecording = false;
                                        mTimer.cancel();
                                        Intent retIntent = new Intent();
                                        //retIntent.putExtra("videoUri", Uri.fromFile(videoFile));
                                        retIntent.setData(Uri.fromFile(videoFile));
                                        setResult(233, retIntent);
                                        finish();
                                    }
                                });
                        }
                    }, 1000, 1000);
                }
                else
                {
                    if(!isRecording)
                    {
                        btnRecord.setText("STOP");
                        isRecording = true;
                        prepareVideoRecorder();
                        try{
                            mMediaRecorder.prepare();
                            mMediaRecorder.start();
                        }
                        catch (Exception x){
                            releaseMediaRecorder();
                        }
                    }
                    else
                    {
                        releaseMediaRecorder();
                        isRecording = false;
                        Intent retIntent = new Intent();
                        retIntent.setData(Uri.fromFile(videoFile));
                        setResult(233, retIntent);
                        finish();
                    }
                }


            }
        });

        findViewById(R.id.btn_facing).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(CAMERA_TYPE == Camera.CameraInfo.CAMERA_FACING_BACK)
                    CAMERA_TYPE = Camera.CameraInfo.CAMERA_FACING_FRONT;
                else
                    CAMERA_TYPE = Camera.CameraInfo.CAMERA_FACING_BACK;
                releaseCameraAndPreview();
                mCamera = getCamera(CAMERA_TYPE);
                startPreview(holder);
            }
        });

        final Button btn_flashlight = findViewById(R.id.btn_flashlight);
        btn_flashlight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Camera.Parameters paras = mCamera.getParameters();
                if(btn_flashlight.getText().toString().equals("flashlight"))
                {
                    paras.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                    btn_flashlight.setText("off");
                    mCamera.setParameters(paras);
                }
                else
                {
                    btn_flashlight.setText("flashlight");
                    paras.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                    mCamera.setParameters(paras);
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mTimer.cancel();
        if(mCamera != null && isRecording)
            releaseMediaRecorder();
        if (mCamera != null) {
            releaseCameraAndPreview();
        }
    }

    public Camera getCamera(int position) {
        CAMERA_TYPE = position;
        if (mCamera != null) {
            releaseCameraAndPreview();
        }
        Camera cam = Camera.open(position);

        //todo 摄像头添加属性，例是否自动对焦，设置旋转方向等
        rotationDegree = getCameraDisplayOrientation(position);
        cam.setDisplayOrientation(rotationDegree);

        if(CAMERA_TYPE == Camera.CameraInfo.CAMERA_FACING_BACK)
        {
            Camera.Parameters para;
            para = cam.getParameters();
            List<String> focusModes = para.getSupportedFocusModes();
            if (focusModes.contains(para.FOCUS_MODE_CONTINUOUS_VIDEO))
                para.setFocusMode(para.FOCUS_MODE_CONTINUOUS_VIDEO);
            para.setFocusMode(para.FOCUS_MODE_CONTINUOUS_VIDEO);
            cam.setParameters(para);
        }

        return cam;
    }


    private static final int DEGREE_90 = 90;
    private static final int DEGREE_180 = 180;
    private static final int DEGREE_270 = 270;
    private static final int DEGREE_360 = 360;

    private int getCameraDisplayOrientation(int cameraId) {
        android.hardware.Camera.CameraInfo info =
                new android.hardware.Camera.CameraInfo();
        android.hardware.Camera.getCameraInfo(cameraId, info);
        int rotation = getWindowManager().getDefaultDisplay()
                .getRotation();
        int degrees = 0;
        switch (rotation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;
            case Surface.ROTATION_90:
                degrees = DEGREE_90;
                break;
            case Surface.ROTATION_180:
                degrees = DEGREE_180;
                break;
            case Surface.ROTATION_270:
                degrees = DEGREE_270;
                break;
            default:
                break;
        }

        int result;
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            result = (info.orientation + degrees) % DEGREE_360;
            result = (DEGREE_360 - result) % DEGREE_360;  // compensate the mirror
        } else {  // back-facing
            result = (info.orientation - degrees + DEGREE_360) % DEGREE_360;
        }
        return result;
    }


    private void releaseCameraAndPreview() {
        if(mCamera == null) return;
        mCamera.stopPreview();
        mCamera.release();
        mCamera = null;
    }

    Camera.Size size;

    private void startPreview(SurfaceHolder holder) {
        try {
            mCamera.setPreviewDisplay(holder);
            mCamera.startPreview();
        }catch (Exception x) {}
    }


    private MediaRecorder mMediaRecorder;
    private File videoFile;

    private boolean prepareVideoRecorder() {
        mCamera.unlock();
        mMediaRecorder = new MediaRecorder();
        mMediaRecorder.setCamera(mCamera);
        mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);
        mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);
        mMediaRecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_HIGH));
        videoFile = new File(getOutputMediaFile(MEDIA_TYPE_VIDEO).toString());
        mMediaRecorder.setOutputFile(videoFile.toString());
        mMediaRecorder.setPreviewDisplay(mSurfaceView.getHolder().getSurface());
        mMediaRecorder.setOrientationHint(rotationDegree);
        return true;
    }


    private void releaseMediaRecorder() {
        Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        Uri uri = Uri.fromFile(videoFile);
        intent.setData(uri);
        sendBroadcast(intent);
        mMediaRecorder.stop();
        mMediaRecorder.reset();
        mMediaRecorder.release();
        mMediaRecorder = null;
        mCamera.lock();
    }

}

package com.example.minidouyin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintHelper;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Point;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.PersistableBundle;
import android.print.PrintAttributes;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.VideoView;

import com.example.minidouyin.classes.DoubleClickListener;

import java.util.HashMap;
import java.util.concurrent.ScheduledExecutorService;

import static android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT;
import static android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION;
import static android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH;
import static java.lang.Math.min;

public class VideoActivity extends AppCompatActivity {

    private static final int DOUBLE_CLICK_INTERVAL = 400;
    private static final int SINGLE_CLICK_MESSAGE = 4444;
    private static final int DOUBLE_CLICK_MESSAGE = 6666;

    private VideoView videoPlay;

    private int curVideoMs = 0;
    private static int savedVideoState = -1;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            final int vid = msg.arg1;
            final float cX = msg.getData().getFloat("X");
            final float cY = msg.getData().getFloat("Y");
            switch (msg.what) {
                case SINGLE_CLICK_MESSAGE:
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            VideoView v = findViewById(vid);
                            if(v.isPlaying()) v.pause(); else v.start();
                        }
                    });
                    break;
                case DOUBLE_CLICK_MESSAGE:
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            ImageView img = VideoActivity.this.findViewById(R.id.double_clk_heart);
                            ConstraintLayout layout = VideoActivity.this.findViewById(R.id.video_play_area);

                            ConstraintSet applyConstraints = new ConstraintSet();
                            applyConstraints.clone(layout);
                            applyConstraints.setMargin(R.id.double_clk_heart, ConstraintSet.START, (int)cX - img.getWidth() / 2);
                            applyConstraints.setMargin(R.id.double_clk_heart, ConstraintSet.TOP, (int)cY - img.getHeight() / 2);
                            applyConstraints.applyTo(layout);

                            img.setVisibility(View.VISIBLE);
                            Animator anim = AnimatorInflater.loadAnimator(VideoActivity.this, R.animator.double_click_on_video);
                            anim.setTarget(img);
                            anim.start();
                            //layout.addView(img);
                        }
                    });
                    break;
            }
        }
    };

    static long mLastTime = 0, mCurTime = 0;

    public static void launch(Activity activity, String url) {
        savedVideoState = -1;
        Intent intent = new Intent(activity, VideoActivity.class);
        intent.putExtra("url", url);
        activity.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.video_activity_layout);
        String url = getIntent().getStringExtra("url");
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ConstraintLayout mainScreen = findViewById(R.id.video_play_area);

        final MediaMetadataRetriever videoInfoRetriever = new MediaMetadataRetriever();
        videoInfoRetriever.setDataSource(url, new HashMap<String, String>());
        int height = Integer.valueOf(videoInfoRetriever.extractMetadata(METADATA_KEY_VIDEO_HEIGHT));
        int width = Integer.valueOf(videoInfoRetriever.extractMetadata(METADATA_KEY_VIDEO_WIDTH));
        int rotation = Integer.valueOf(videoInfoRetriever.extractMetadata(METADATA_KEY_VIDEO_ROTATION));
        if(rotation == 90 || rotation == 270)
        {
            int tmp = height; height = width; width = tmp;
        }

        ConstraintLayout videoContainer = findViewById(R.id.video_activity_play_container);
        Point maxpos = new Point();
        getWindowManager().getDefaultDisplay().getSize(maxpos);
        int maxh = maxpos.y, maxw = maxpos.x;
        double ratio = min(maxh*1.0/height, maxw*1.0/width);

        ViewGroup.LayoutParams params;
        params = videoContainer.getLayoutParams();

        params.height = (int)(height * ratio);
        params.width = (int)(width * ratio);
        videoContainer.setLayoutParams(params);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////


        videoPlay = findViewById(R.id.video_play);
        final ProgressBar progressBar = findViewById(R.id.progress_bar);
        videoPlay.setMediaController(new MediaController(this));
        videoPlay.setVideoURI(Uri.parse(url));
        videoPlay.requestFocus();
        videoPlay.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                progressBar.setVisibility(View.GONE);
                if(savedVideoState != -1)
                {
                    videoPlay.seekTo(savedVideoState);
                }
            }
        });
        if(savedInstanceState != null && savedInstanceState.containsKey("curVideoMs"))
        {
            videoPlay.seekTo(savedInstanceState.getInt("curVideoMs"));
        }
        videoPlay.start();

        progressBar.setVisibility(View.VISIBLE);

        mainScreen.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {

                Message singleClickMsg = Message.obtain();
                Message doubleClickMsg = Message.obtain();
                singleClickMsg.what = SINGLE_CLICK_MESSAGE;
                doubleClickMsg.what = DOUBLE_CLICK_MESSAGE;
                singleClickMsg.arg1 = R.id.video_play;
                Bundle coordinate = new Bundle();
                coordinate.putFloat("X", event.getX());
                coordinate.putFloat("Y", event.getY());
                doubleClickMsg.setData(coordinate);

                mLastTime = mCurTime;
                mCurTime = System.currentTimeMillis();
                if(mCurTime - mLastTime < DOUBLE_CLICK_INTERVAL){//双击事件
                    mCurTime = 0;
                    mLastTime = 0;
                    handler.removeMessages(SINGLE_CLICK_MESSAGE);
                    handler.sendMessage(doubleClickMsg);
                }else{//单击事件
                    handler.sendMessageDelayed(singleClickMsg, DOUBLE_CLICK_INTERVAL + 10);
                }
                return false;
            }
        });

    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        if(savedInstanceState != null)
            if(savedInstanceState.containsKey("curVideoMs"))
                videoPlay.seekTo(savedInstanceState.getInt("curVideoMs"));
        super.onRestoreInstanceState(savedInstanceState);
    }

    @Override
    protected void onPause() {
        curVideoMs = videoPlay.getCurrentPosition();
        savedVideoState = curVideoMs;
        super.onPause();
    }

    @Override
    protected void onResume() {
        videoPlay.seekTo(curVideoMs);
        super.onResume();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState, @NonNull PersistableBundle outPersistentState) {
        curVideoMs = videoPlay.getCurrentPosition();
        outState.putInt("curVideoMs", curVideoMs);
        super.onSaveInstanceState(outState, outPersistentState);
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }

}


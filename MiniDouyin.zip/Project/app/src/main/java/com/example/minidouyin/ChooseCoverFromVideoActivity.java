package com.example.minidouyin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.SeekBar;
import android.widget.VideoView;

import com.example.minidouyin.R;
import com.example.minidouyin.resource_service.FileService;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Collections;

import retrofit2.http.Url;

import static android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT;
import static android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION;
import static android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH;
import static android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE;
import static android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;
import static java.lang.Math.min;

public class ChooseCoverFromVideoActivity extends AppCompatActivity {

    private static final int SEEKBAR_MAX = 1000000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_cover_from_video);
        setTitle("Choose the cover image");

        final VideoView videoView = findViewById(R.id.video_choose_frame);
        Intent videoInfoIntent = getIntent();
        Uri videoUri = videoInfoIntent.getData();

        final MediaMetadataRetriever videoInfoRetriever = new MediaMetadataRetriever();
        videoInfoRetriever.setDataSource(this, videoUri);
        int height = Integer.valueOf(videoInfoRetriever.extractMetadata(METADATA_KEY_VIDEO_HEIGHT));
        int width = Integer.valueOf(videoInfoRetriever.extractMetadata(METADATA_KEY_VIDEO_WIDTH));
        int rotation = Integer.valueOf(videoInfoRetriever.extractMetadata(METADATA_KEY_VIDEO_ROTATION));
        if(rotation == 90 || rotation == 270)
        {
            int tmp = height; height = width; width = tmp;
        }

        LinearLayout videoContainer = findViewById(R.id.video_choose_frame_container);
        int maxh = videoContainer.getLayoutParams().height;
        int maxw = videoContainer.getLayoutParams().width;
        double ratio = min(maxh*1.0/height, maxw*1.0/width);

        ViewGroup.LayoutParams params;
        params = videoContainer.getLayoutParams();

        params.height = (int)(height * ratio);
        params.width = (int)(width * ratio);
        videoContainer.setLayoutParams(params);
        //videoContainer.setBackgroundColor(Color.RED);

        videoView.setVideoURI(videoUri);
        videoView.setMediaController(new MediaController(this));

        final SeekBar sb = findViewById(R.id.sb_find_frame);
        sb.setMax(SEEKBAR_MAX);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if(videoView.isPlaying()) videoView.pause();
                int maxms = videoView.getDuration();
                videoView.seekTo((int)(1.0 * i * maxms / SEEKBAR_MAX));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        final Button btnChoose = findViewById(R.id.btn_choose_this_frame);
        btnChoose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnChoose.setText("Please wait a moment...");
                btnChoose.setEnabled(false);
                int curms = videoView.getCurrentPosition();
                Bitmap choosedBmp = videoInfoRetriever.getFrameAtTime(curms * 1000);
                File newFile = FileService.getOutputMediaFile(MEDIA_TYPE_IMAGE);
                Uri newUri = Uri.fromFile(newFile);
                FileOutputStream fos = null;
                try
                {
                    fos = new FileOutputStream(newFile);
                    choosedBmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    fos.flush();
                }
                catch (Exception x){}
                finally {
                    try
                    {
                        if(fos != null) fos.close();
                    } catch (Exception x){x.printStackTrace();}
                }
                Intent feedback = new Intent();
                feedback.setData(newUri);
                CheckBox cb = findViewById(R.id.cb_post_after_choose);
                if(cb.isChecked())
                    feedback.putExtra("immediate_post", true);
                else
                    feedback.putExtra("immediate_post", false);
                setResult(233, feedback);
                finish();
            }
        });

    }
}

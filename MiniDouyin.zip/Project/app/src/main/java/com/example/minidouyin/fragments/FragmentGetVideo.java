package com.example.minidouyin.fragments;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.minidouyin.R;
import com.example.minidouyin.classes.VideoAdapter;
import com.example.minidouyin.classes.VideoViewHolder;
import com.example.minidouyin.database_service.UserFavoriteDBHelper;
import com.example.minidouyin.network_models.GetFeeds;
import com.example.minidouyin.network_models.Video;
import com.example.minidouyin.network_service.IMiniDouyinService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class FragmentGetVideo extends Fragment {

    private Retrofit retrofit;
    private IMiniDouyinService miniDouyinService;
    static private List<Video> videos = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        super.onCreateView(inflater, container, savedInstanceState);

        retrofit = new Retrofit.Builder().baseUrl("http://test.androidcamp.bytedance.com/mini_douyin/invoke/")
                .addConverterFactory(GsonConverterFactory.create()).build();
        miniDouyinService = retrofit.create(IMiniDouyinService.class);

        View view = inflater.inflate(R.layout.fragment_get_video, container, false);
        final Button getBtn = view.findViewById(R.id.get_video_btn);
        final TextView info = view.findViewById(R.id.get_video_info);
        final Activity thisAct = this.getActivity();

        final RecyclerView videoRv = view.findViewById(R.id.video_list_container);
        videoRv.setLayoutManager(new LinearLayoutManager(this.getContext()));
        if(videos == null) videos = new ArrayList<>();
        VideoAdapter adapter = new VideoAdapter(getActivity(), videos);
        videoRv.setAdapter(adapter);

        getBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                info.setText("Please wait a moment...");
                getBtn.setTextSize(10f);
                getBtn.setText("requesting");
                getBtn.setEnabled(false);

                Call<GetFeeds> call = miniDouyinService.getAllVideos();
                call.enqueue(new Callback<GetFeeds>() {

                    @Override
                    public void onResponse(Call<GetFeeds> call, Response<GetFeeds> response) {
                        if(response != null && response.isSuccessful() && response.body().successful)
                        {
                            info.setText("Videos successfully acquired.");
                            GetFeeds feed = response.body();
                            videos = feed.videos;

                            videoRv.setAdapter(new VideoAdapter(FragmentGetVideo.this.getActivity(), videos));
                        }
                        else
                        {
                            info.setText("An error occurred. Please try again.");
                        }
                        getBtn.setEnabled(true);
                        getBtn.setTextSize(15f);
                        getBtn.setText("Refresh");
                    }

                    @Override
                    public void onFailure(Call<GetFeeds> call, Throwable throwable) {
                        info.setText("An error occurred. Please try again.");
                        getBtn.setEnabled(true);
                        getBtn.setTextSize(15f);
                        getBtn.setText("Refresh");
                    }
                });
            }
        });

        return view;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }
}

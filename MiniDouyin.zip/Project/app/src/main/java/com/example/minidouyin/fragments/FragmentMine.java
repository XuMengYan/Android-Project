package com.example.minidouyin.fragments;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.minidouyin.MainActivity;
import com.example.minidouyin.R;
import com.example.minidouyin.classes.VideoAdapter;
import com.example.minidouyin.classes.VideoViewHolder;
import com.example.minidouyin.database_service.DBOperations;
import com.example.minidouyin.database_service.UserFavoriteDBHelper;
import com.example.minidouyin.network_models.GetFeeds;
import com.example.minidouyin.network_models.Video;
import com.example.minidouyin.network_service.IMiniDouyinService;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class FragmentMine extends Fragment {

    private Retrofit retrofit;
    private IMiniDouyinService miniDouyinService;

    static boolean firstOpen = true;
    public static String userName = new String();
    public static String userID = new String();
    static private List<Video> videos = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {

        if(firstOpen)
        {
            firstOpen = false;
            if(DBOperations.loggedIn())
            {
                userName = DBOperations.getUserName();
                userID = DBOperations.getUserID();
            }
        }

        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_mine, container, false);
        final View fview = view;

        retrofit = new Retrofit.Builder().baseUrl("http://test.androidcamp.bytedance.com/mini_douyin/invoke/")
                .addConverterFactory(GsonConverterFactory.create()).build();
        miniDouyinService = retrofit.create(IMiniDouyinService.class);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        final EditText nameEdit = view.findViewById(R.id.edit_user_name);
        final EditText idEdit = view.findViewById(R.id.edit_user_id);
        final Button loginBtn = view.findViewById(R.id.btn_user_login);
        final RecyclerView videoRv = view.findViewById(R.id.rv_my_favorite);
        if(userName.length() > 0 && userID.length() > 0)
        {
            nameEdit.setText(userName);
            idEdit.setText(userID);
            nameEdit.setEnabled(false);
            idEdit.setEnabled(false);
            loginBtn.setText("Log off");
        }
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(loginBtn.getText().toString().equals("Log in"))
                {
                    String name = nameEdit.getText().toString();
                    String id = idEdit.getText().toString();
                    if(name.length() == 0 || id.length() == 0)
                    {
                        Toast.makeText(FragmentMine.this.getContext(), "Please enter user name and id", Toast.LENGTH_LONG).show();
                        return ;
                    }
                    userName = new String(name);
                    userID = new String(id);
                    DBOperations.setUser(userName, userID);
                    nameEdit.setEnabled(false);
                    idEdit.setEnabled(false);
                    FileWriter writer = null;
                    try
                    {
                        File file = new File(FragmentMine.this.getContext().getFilesDir() + "/login.txt");
                        if(!file.exists()) file.createNewFile();
                        writer = new FileWriter(file);
                        writer.write(DBOperations.getUserName() + '\n' + DBOperations.getUserID());
                        writer.close();
                    }
                    catch (Exception x)
                    {   }
                    finally {
                        try
                        {
                            if(writer != null) writer.close();
                        }
                        catch (Exception x){
                            Toast.makeText(FragmentMine.this.getContext(), "File IO Failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                    loginBtn.setText("Log off");
                }
                else
                {
                    userName = new String();
                    userID = new String();
                    DBOperations.logOff();
                    nameEdit.setEnabled(true);
                    idEdit.setEnabled(true);
                    loginBtn.setText("Log in");
                    videos.clear();
                    videoRv.setAdapter(new VideoAdapter(FragmentMine.this.getActivity(), videos));
                    FileWriter writer = null;
                    try
                    {
                        File file = new File(FragmentMine.this.getContext().getFilesDir() + "/login.txt");
                        if(!file.exists()) file.createNewFile();
                        writer = new FileWriter(file);
                        writer.write("");
                        writer.close();
                    }
                    catch (Exception x)
                    {   }
                    finally {
                        try
                        {
                            if(writer != null) writer.close();
                        }
                        catch (Exception x){
                            Toast.makeText(FragmentMine.this.getContext(), "File IO Failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        final Button getBtn = view.findViewById(R.id.btn_refresh_favorite);
        final Activity thisAct = this.getActivity();

        videoRv.setLayoutManager(new LinearLayoutManager(this.getContext()));
        if(videos == null) videos = new ArrayList<>();
        VideoAdapter adapter = new VideoAdapter(getActivity(), videos);
        videoRv.setAdapter(adapter);

        getBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!DBOperations.loggedIn())
                {
                    Toast.makeText(FragmentMine.this.getContext(), "Please log in first", Toast.LENGTH_LONG).show();
                    return;
                }

                getBtn.setTextSize(10f);
                getBtn.setText("requesting");
                getBtn.setEnabled(false);

                Call<GetFeeds> call = miniDouyinService.getAllVideos();
                call.enqueue(new Callback<GetFeeds>() {

                    @Override
                    public void onResponse(Call<GetFeeds> call, Response<GetFeeds> response) {
                        if(response != null && response.isSuccessful() && response.body().successful)
                        {
                            Toast.makeText(FragmentMine.this.getContext(), "Refresh successful.", Toast.LENGTH_SHORT).show();
                            GetFeeds feed = response.body();
                            videos = feed.videos;
                            List<String> fav = DBOperations.getFavoriteUrl();
                            List<Video> realvideos = new ArrayList<>();
                            for(int i = 0; i < videos.size(); ++i)
                            {
                                if(fav.contains(videos.get(i).getVideoUrl()))
                                    realvideos.add(videos.get(i));
                            }
                            videos = realvideos;
                            videoRv.setAdapter(new VideoAdapter(thisAct, videos));
                        }
                        else
                        {
                            Toast.makeText(FragmentMine.this.getContext(), "An Error Occurred", Toast.LENGTH_SHORT).show();
                        }
                        getBtn.setEnabled(true);
                        getBtn.setTextSize(15f);
                        getBtn.setText("Refresh");
                    }

                    @Override
                    public void onFailure(Call<GetFeeds> call, Throwable throwable) {
                        Toast.makeText(FragmentMine.this.getContext(), "An Error Occurred", Toast.LENGTH_SHORT).show();
                        getBtn.setEnabled(true);
                        getBtn.setTextSize(15f);
                        getBtn.setText("Refresh");
                    }
                });
            }
        });


        return view;

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

}
